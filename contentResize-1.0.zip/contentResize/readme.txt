=== Plugin Name ===
Contributors: vinicius gomes
Donate link: http://viniwp.wordpress.com/
Tags: content,resize,excerpt,posts resize, write
Requires at least: 3.1
Tested up to: 3.1
Stable tag: 1.0

Plugin simples para criar resumos com determinado número de palavras de um conteúdo.

== Description ==

Plugin simples para criar resumos com determinado número de palavras de um conteúdo..


== Installation ==


1. Upload plugin folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php content-resize($text,$size,$option); ?>` in your templates

== Frequently Asked Questions ==

View the menu admin

== Screenshots ==

No screenshots
== Changelog ==

= 1.0 =
* Implementação.

